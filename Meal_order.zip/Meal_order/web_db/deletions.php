<?php 
require_once 'connection.php';
class deletions{


 function deleteFrom_account( $account_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM account where account_id =:account_id");
$smt->bindValue(':account_id',$account_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_account_category( $account_category_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM account_category where account_category_id =:account_category_id");
$smt->bindValue(':account_category_id',$account_category_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_profile( $profile_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM profile where profile_id =:profile_id");
$smt->bindValue(':profile_id',$profile_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_image( $image_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM image where image_id =:image_id");
$smt->bindValue(':image_id',$image_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_dish( $dish_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM dish where dish_id =:dish_id");
$smt->bindValue(':dish_id',$dish_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_items( $items_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM items where items_id =:items_id");
$smt->bindValue(':items_id',$items_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_order( $order_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM order where order_id =:order_id");
$smt->bindValue(':order_id',$order_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


}

