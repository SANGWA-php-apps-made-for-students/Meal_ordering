<?php

require_once 'connection.php';
class updates{

 function update_account( $account_category, $date_created, $profile, $username, $password, $is_online,$account_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE account set 
account_category= ?, date_created= ?, profile= ?, username= ?, password= ?, is_online= ? WHERE account_id=?");
$stmt->execute(array($account_category, $date_created, $profile, $username, $password, $is_online ,$account_id ));

}
 function update_account_category( $name,$account_category_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE account_category set 
name= ? WHERE account_category_id=?");
$stmt->execute(array($name ,$account_category_id ));

}
 function update_profile( $dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image,$profile_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE profile set 
dob= ?, name= ?, last_name= ?, gender= ?, telephone_number= ?, email= ?, residence= ?, image= ? WHERE profile_id=?");
$stmt->execute(array($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image ,$profile_id ));

}
 function update_image( $path,$image_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE image set 
path= ? WHERE image_id=?");
$stmt->execute(array($path ,$image_id ));

}
 function update_dish( $price, $picture, $name,$dish_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE dish set 
price= ?, picture= ?, name= ? WHERE dish_id=?");
$stmt->execute(array($price, $picture, $name ,$dish_id ));

}
 function update_items( $name, $dish,$items_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE items set 
name= ?, dish= ? WHERE items_id=?");
$stmt->execute(array($name, $dish ,$items_id ));

}
 function update_order( $entry_date, $User, $tel, $dish,$order_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE order set 
entry_date= ?, User= ?, tel= ?, dish= ? WHERE order_id=?");
$stmt->execute(array($entry_date, $User, $tel, $dish ,$order_id ));

}

}

