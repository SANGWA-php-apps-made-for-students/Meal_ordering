<?php

class new_values {

    function new_account($account_category, $date_created, $profile, $username, $password, $is_online) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into account values(:account_id, :account_category,  :date_created,  :profile,  :username,  :password,  :is_online)");
            $stm->execute(array(':account_id' => 0, ':account_category' => $account_category, ':date_created' => $date_created, ':profile' => $profile, ':username' => $username, ':password' => $password, ':is_online' => $is_online
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_account_category($name) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into account_category values(:account_category_id, :name)");
            $stm->execute(array(':account_category_id' => 0, ':name' => $name
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_profile($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into profile values(:profile_id, :dob,  :name,  :last_name,  :gender,  :telephone_number,  :email,  :residence,  :image)");
            $stm->execute(array(':profile_id' => 0, ':dob' => $dob, ':name' => $name, ':last_name' => $last_name, ':gender' => $gender, ':telephone_number' => $telephone_number, ':email' => $email, ':residence' => $residence, ':image' => $image
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_image($path) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into image values(:image_id, :path)");
            $stm->execute(array(':image_id' => 0, ':path' => $path
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_dish($price, $picture, $name) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into dish values(:dish_id, :price,  :picture,  :name)");
            $stm->execute(array(':dish_id' => 0, ':price' => $price, ':picture' => $picture, ':name' => $name
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_items($name, $dish) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into items values(:items_id, :name,  :dish)");
            $stm->execute(array(':items_id' => 0, ':name' => $name, ':dish' => $dish
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_order($entry_date, $User, $tel, $dish) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into order values(:order_id, :entry_date,  :User,  :tel,  :dish)");
            $stm->execute(array(':order_id' => 0, ':entry_date' => $entry_date, ':User' => $User, ':tel' => $tel, ':dish' => $dish
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

}
