//<editor-fold defaultstate="collapsed" desc="these variables are used in the delete and update of the table records">
var table_to_update = '';
var table_to_delete = '';
var id_delete = 0;
var id_update = 0;
var current_del_btn = null;
//</editor-fold>
$(document).ready(function () {


    try {
        get_new_data_hide_show();
        show_form_toUpdate();
        order_del_udpate();
//get_pages_moving();
        dlog_btn_No_Yes();
        hide_select_pane();
        hide_Y_N_dialog();
        order_del_udpate();
        account_del_udpate();
        account_category_del_udpate();
        profile_del_udpate();
        image_del_udpate();
        dish_del_udpate();
        items_del_udpate();
        order_del_udpate();

        get_account_category_id_combo();
        get_profile_id_combo();
        get_image_id_combo();
        get_dish_id_combo();
        confirm_order();
        switiching_order_panes();
        item_clicked();
        search_item_by_typing();
        selectable_link_click();
        show_profiles();
        show_categories();
        show_Items();
        load();
    } catch (err) {
        alert(err);
    }
});

function get_account_category_id_combo() {
    try {
        $('.cbo_account_category').change(function () {
            var cbo_account_category = $('.cbo_account_category option:selected').val();
            $('#txt_account_category_id').val(cbo_account_category);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_profile_id_combo() {
    try {
        $('.cbo_profile').change(function () {
            var cbo_profile = $('.cbo_profile option:selected').val();
            $('#txt_profile_id').val(cbo_profile);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_image_id_combo() {
    try {
        $('.cbo_image').change(function () {
            var cbo_image = $('.cbo_image option:selected').val();
            $('#txt_image_id').val(cbo_image);
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_dish_id_combo() {
    try {
        $('.cbo_dish').change(function () {
            var cbo_dish = $('.cbo_dish option:selected').val();
            $('#txt_dish_id').val(cbo_dish);
        });
    } catch (err) {
        alert(err.message);
    }
}
function cancel_update() {
    $('.cancel_btn').unbind('click').click(function () {
        var cancel_update = $(this).data('cancel_name');
        $.post('../admin/handler.php', {cancel_update: cancel_update}, function (data) {
        }).complete(function () {
            window.location.reload();
        });
    });
}
function hide_Y_N_dialog() {//here the user will be confirming to delete the record
    $('#user_yes_btn,  .yes_dlg_btn').click(function () {
        $.post('../admin/handler.php', {id_delete: id_delete, table_to_delete: table_to_delete}, function (data) {

        }).complete(function () {
            $('.y_n_dialog').fadeOut(300);
            current_del_btn.closest('tr').slideUp(400);
            $('.menu').show();
            $('.abs_full').fadeOut(100);
//            window.location.reload();
        });
    });
    $('#no_btn, .no_btn, .abs_full').click(function () {
        $('.y_n_dialog').fadeOut(300);
        $('.abs_full').fadeOut(10);
        $('.menu').show();
    });
    $('.abs_full').click(function () {
        $(this).fadeOut(200, function () {
            $('.y_n_dialog').fadeOut(70);
        });
    });
}
function show_Y_N_dialog() {
    $('.abs_full').fadeIn(300, function () {
        $('.y_n_dialog').fadeIn(0);
    });
}
function get_new_data_hide_show() {
    $('.new_data_hider').click(function () {

        $('.new_data_box').slideToggle(100);


//        if ($('.new_data_box').is('visible')) {
//             $('.new_data_box').slideUp(100);
//        }else if(!$('.new_data_box').is('visible')){
//            $('.new_data_box').slideDown(100);
//        }

    });

}
function validate_numbers_textfields() {
    $('.only_numbers').keydown(function (e) {
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
                // Allow: Ctrl+A, Command+A
                        (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
                        // Allow: home, end, left, right, down, up
                                (e.keyCode >= 35 && e.keyCode <= 40)) {
                    // let it happen, don't do anything
                    return;
                }
                // Ensure that it is a number and stop the keypress
                if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                    e.preventDefault();
                }
            });
}
function hover_theme1() {
    $('.hover_theme1').mouseover(function () {
        $(this).css('background-color', '#29f15c');
        $(this).addClass('no_shade_noBorder');
        $(this).css('cursoer', 'pointer');
    });

    $('.hover_theme1').mouseleave(function () {
        $(this).css('background-color', 'transparent');
        $(this).removeClass('no_shade_noBorder');
    });
}
function show_form_toUpdate() {
    var updname = $('#txt_shall_expand_toUpdate').val();
    if (updname != '') {
        $('.new_data_box').delay(200).slideDown();
    }

}
function postDisplayData(call_dialog, div) {
    $.post('../Admin/handler.php', {call_dialog: call_dialog}, function (data) {
        $(div).html(data);
    }).complete(function () {
        $('.msg_dialog').slideDown(300);
    });
}
function dlog_btn_No_Yes() {
    $('#dlog_btnNo').unbind('click').click(function () {
        alert('Confirmed!');
    });
    $('#dlog_btnYs').unbind('click').click(function () {
        alert('Declined!');
    });
}
function hide_select_pane() {
    $('.foreign_select').unbind('click').click(function () {
        $(this).fadeOut(200);
        $('.dialog').hide("drop", {direction: 'up'}, 500,
                (function () {
                    $('.menu').show();
                }));
    });

}


//update from account ...

function account_del_udpate() {
    $('.account_update_link').click(function () {
        table_to_update = $(this).data('table');
        id_update = $(this).data('id_update');
        current_del_btn = $(this);
        $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {
        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromaccount.. 
    $('.account_delete_link').click(function () {
        table_to_delete = $(this).data('table');
        id_delete = $(this).data('id_delete');
        current_del_btn = $(this);
        show_Y_N_dialog();

    });
}
//update from account_category ...

function account_category_del_udpate() {
    $('.account_category_update_link').click(function () {
        table_to_update = $(this).data('table');
        id_update = $(this).data('id_update');
        current_del_btn = $(this);
        $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {
        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromaccount_category.. 
    $('.account_category_delete_link').click(function () {
        table_to_delete = $(this).data('table');
        id_delete = $(this).data('id_delete');
        current_del_btn = $(this);
        show_Y_N_dialog();

    });
}
//update from profile ...

function profile_del_udpate() {
    $('.profile_update_link').click(function () {
        table_to_update = $(this).data('table');
        id_update = $(this).data('id_update');
        current_del_btn = $(this);
        $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {
        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromprofile.. 
    $('.profile_delete_link').click(function () {
        table_to_delete = $(this).data('table');
        id_delete = $(this).data('id_delete');
        current_del_btn = $(this);
        show_Y_N_dialog();

    });
}
//update from image ...

function image_del_udpate() {
    $('.image_update_link').click(function () {
        table_to_update = $(this).data('table');
        id_update = $(this).data('id_update');
        current_del_btn = $(this);
        $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {
        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromimage.. 
    $('.image_delete_link').click(function () {
        table_to_delete = $(this).data('table');
        id_delete = $(this).data('id_delete');
        current_del_btn = $(this);
        show_Y_N_dialog();

    });
}
//update from dish ...

function dish_del_udpate() {
    $('.dish_update_link').click(function () {
        table_to_update = $(this).data('table');
        id_update = $(this).data('id_update');
        current_del_btn = $(this);
        $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {
        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromdish.. 
    $('.dish_delete_link').click(function () {
        table_to_delete = $(this).data('table');
        id_delete = $(this).data('id_delete');
        current_del_btn = $(this);
        show_Y_N_dialog();

    });
}
//update from items ...

function items_del_udpate() {
    $('.items_update_link').click(function () {
        table_to_update = $(this).data('table');
        id_update = $(this).data('id_update');
        current_del_btn = $(this);
        $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {
        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromitems.. 
    $('.items_delete_link').click(function () {
        table_to_delete = $(this).data('table');
        id_delete = $(this).data('id_delete');
        current_del_btn = $(this);
        show_Y_N_dialog();

    });
}
//update from order ...

function order_del_udpate() {
    $('.order_update_link').click(function () {
        table_to_update = $(this).data('table');
        id_update = $(this).data('id_update');
        current_del_btn = $(this);
        $.post('../admin/handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {
        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });//delete fromorder.. 
    $('.order_delete_link').click(function () {
        table_to_delete = $(this).data('table');
        id_delete = $(this).data('id_delete');
        current_del_btn = $(this);
        show_Y_N_dialog();

    });
}


function user_ordering_click() {
    $('.img_box').click(() => {

    });
}


//Addon


function confirm_order() {
    $('.order_confirm_link').click(function () {
        var orderid = $(this).data('bind');


        var update_order_status = 'yes';
        $.post('../admin/handler.php', {update_order_status: update_order_status, orderid: orderid}, function (data) {
            console.log('Data: ' + data);
            alert(data);
        }).complete(function () {
            window.location.reload();
        });

        return false;
    });
}

function switiching_order_panes() {
    $('.opts').mouseover(function () {
        $(this).addClass('chosen_menu');
    }).mouseleave(function () {
//        $(this).removeClass('chosen_menu');
    });
    
    $('.opts:nth(0)').addClass('chosen_menu');
    $('.opts').click(function () {
        var flag = $(this).data('bind');

        $('.opts').removeClass('chosen_menu');
        $(this).addClass('chosen_menu');
        
        console.log(flag);

        $('.order_type_box').hide(0);
        $('.otb_' + flag).slideDown(0);
        $('.lbl_status').html($(this).data('status')+' orders');

    });
}








//Stock
function item_clicked() {
    $('.item_image').unbind('click').click(function () {
        var sp_part = $(this).children('span:first').html();
        itemid = sp_part;
        $('.item_image').removeClass('highlighter');
        $(this).addClass('highlighter');
        $('#edit_hightlight').slideDown(300);

//        $(this).closest('.by_date_container').slideUp(300);
    });
    $('#upd_sp_part').unbind('click').click(function () {
        var upd_sp_part = itemid;
        $.post('../Admin/handler.php', {upd_sp_part: upd_sp_part}, function (data) {
//            alert(data);
        }).complete(function () {
            window.location.replace('redirect.php');
        });

    });
    $('#del_sp_part').unbind('click').click(function () {
        var del_sp_part = itemid;
        get_foreign_click('Do you really want to delete the selected product??', 'delete_stock');
    });

    $('#del_yes').click(function () {
        var del_sp_part = itemid;
        $.post('../Admin/handler.php', {del_sp_part: del_sp_part}, function (data) {
            alert(data);
        }).complete(function () {
            window.location.replace('redirect.php');
        });
    });
    $('#del_no').click(function () {
        itemid = 0;
        $("#delete_stock").hide();
        $(".foreign_select").hide();
        $(".dialog").hide();
        $('.item_image').removeClass('highlighter');
        $('#edit_hightlight').slideUp(300);
    });


    $('#cancel_sp_part').click(function () {
        $('.item_image').removeClass('highlighter');
        $('#edit_hightlight').slideUp(300);
        itemid = 0;
    });
}
function search_item_by_typing() {
    $('#txt_item_name').keyup(function () {
        var item_search = $(this).val();
        $('#searched_item_box').html('loading ...');
        $.post('../Admin/handler.php', {item_search: item_search}, function (data) {
            $('#searched_item_box').html(data);
        });
        if (item_search == '') {
            $('#file_image').show('drop', {direction: 'down'}, 500);
            $('#item_id').val('');
            $('#Qty_check').val('');
        }
    });



}
function selectable_link_click() {
    //account
    $('.select_link_account_category').click(function () {
        var cat_id = $(this).closest('td').siblings('.category_col').text().trim();
        var cat_name = $(this).closest('td').siblings('.cat_names_col').text().trim();
        $('#txt_account_category_id').val(cat_id);
        $('.foreign_select').fadeOut(300);
        $('.dialog').hide("drop", {direction: "up"}, 500);
        $('#name_holder').html('(' + cat_name + ')');

        //request for profile

        //stock for product
    });
    $('.select_link_profile').click(function () {
        var profile_id = $(this).closest('td').siblings('.profile_id_col').text().trim();
        var profile_name = $(this).closest('td').siblings('.profile_names_col').text().trim();
        $('#txt_profile_id').val(profile_id);
        $('.foreign_select').fadeOut(300);
        $('.dialog').hide("drop", {direction: "up"}, 500);
        $('#selected_profile').html('(' + profile_name + ')');

        //request for profile

        //stock for product
    });
    $('.select_link_stockstock').click(function () {
        var item_id = $(this).closest('td').siblings('.item_id_col').text().trim();
        var item_name = $(this).closest('td').siblings('.item_name_col').text().trim();
        $('#txt_item_id').val(item_id);
        var quantity_av = item_id;
        $('#item_id_holder').html('(' + item_name + ')');
        $('.foreign_select').fadeOut(300);
        $('.dialog').hide("drop", {direction: "up"}, 500);
        $.post('../Admin/handler.php', {quantity_av: quantity_av}, function (data) {
            $('#Qty_check').val(data);
        });
    });

}
function get_foreign_click(dialog_title, table) {
    $(".foreign_select").show("puff", {percent: 100}, 100, function () {
        $('.dialog').show("drop", {direction: 'up'}, 500);
    });
    $('.dialog_title').html(dialog_title);
    //we hide all the table and show only one table
    $('.tables').hide();
    $('#' + table).show();
    //here is to show the dialog   
}

function show_profiles() {
    $('#foreign_acc_profile').unbind('click').click(function () {
        get_foreign_click('select a person', 'profile');
    });
}
function show_categories() {
    $('#foreign_acc_category').click(function () {
        get_foreign_click('select a category', 'category');

    });
}
function show_Items() {
    $('#foreign_select_item').click(function () {
        get_foreign_click('Pick a spare part', 'spares');
    });

}
function load() {
    $('.foreign_select').unbind('click').click(function () {
        $(this).fadeOut(300);
        $('.dialog').hide("drop", {direction: "up"}, 500);
    });


    //check if the page is going to update or save
    var flag = $('#update_or_not').val();
    ;
    if (flag > 0) {
        $('#data_div_sp_part').delay(2000).slideDown(300);
    } else {

    }
}