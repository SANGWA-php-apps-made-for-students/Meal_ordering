<?php
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_requests'])) {
    $profile = $_POST['txt_profile_id'];
    if (!empty($_POST['txt_profile_id'])) {
        $requestsdeleted = 'no';
        $date = date("Y-m-d");
        $qty = $_POST['txt_qty']; // amount to remove(requeste)
        $qty_check = $_POST['Qty_check']; //amount available
        if ($qty > $qty_check) {
            ?>      <script>      alert('The amount is insuficient !!');</script>            <?php
        } else {
            $item_id = $_POST['txt_item_id'];
            $account = $_SESSION['userid'];
            $profile = $_POST['txt_profile_id']; //This will be  chose from the list (the workers or anyone requesting for the spare part)
            require_once '../web_db/new_values.php';
            $obj = new new_values();
            $obj->new_requests($requestsdeleted, $date, $qty, $account, $profile, $item_id);

            //update stockc
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $upd_obj->update_stock_qty($qty_check - $qty, $item_id);
        }
    } else {
        ?>      <script>  alert('You have to choose the person who is requesting the item !!');</script>            <?php
    }
}
?>

<html>
    <head>
        <title>
            requests</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/> 
        <link href="admin_style.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/></head>  
    <body>
        <form action="new_requests.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_account_id"   name="txt_account_id"/>
            <input type="hidden" id="txt_profile_id"   name="txt_profile_id"/>
            <input type="hidden" id="txt_item_id"   name="txt_item_id"/>
            <input type="hidden" id="Qty_check"   name="Qty_check"/>
            <?php
            include 'admin_header.php';
            ?>
            <div class="parts eighty_centered no_paddin_shade_no_Border">
                <div class="    new_data_hider link_cursor"> Hide </div>  
            </div>
            <div class="parts eighty_centered off saved_dialog">
                requests saved successfully!</div>
            <div class="parts eighty_centered new_data_box off">
                <div class="parts heading "> New stock out</div>
                <table class="new_data_table">
                    <tr><td>Item :</td><td> 
                            <a href="#" id="foreign_select_item" class="foreign_select_link" style="color: #000080">Select</a><span id="item_id_holder" ></span>
                        </td></tr>
                    <tr><td>Quantity :</td><td> <input type="text"     name="txt_qty" required class="textbox only_numbers" />  </td></tr>
                    <tr><td>profile :</td><td>  <a href="#" id="foreign_acc_profile" class="foreign_select_link" style="color: #000080">Select</a>
                            <?php include './Foreign_selects.php'; ?>  <span id="selected_profile"></span>    </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_requests" value="Save"/>  </td></tr>
                </table>
            </div>
            <div class="parts eighty_centered datalist_box" >
                <div class="parts heading">Movements report</div>
                <?php
                $obj = new multi_values();
                $obj->list_requests();
                ?>
            </div>
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="date_picker/jquery-ui.min.js" type="text/javascript"></script>
        <script src="date_picker/jquery-ui.js" type="text/javascript"></script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_account_combo() {
    $obj = new multi_values();
    $obj->get_account_in_combo();
}

function get_profile_combo() {
    $obj = new multi_values();
    $obj->get_profile_in_combo();
}

function list_selectable_acc_cat() {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from account_category ";
    ?>
    <table class="dataList_table">
        <thead><tr>
                <td> ID </td>
                <td> name </td>
                <td>Option</td>
        </thead>
        <?php foreach ($db->query($sql) as $row) { ?><tr>
                <td class="category_col">
                    <?php echo $row['account_category_id']; ?>
                </td>
                <td class="cat_names_col">
                    <?php echo $row['name']; ?>
                </td>

                <td>
                    <a href="#" class="select_link_account_category" style="color: #000080;" value="
                       <?php echo $row['account_category_id']; ?>">Select</a>
                </td></tr>
        <?php } ?></table>
    <?php
}
