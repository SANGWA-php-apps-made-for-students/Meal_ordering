<html>
    <head>
        <title>Admin dashboard</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <style>
            .admin_heeader{
                background-color: #de731c;
                color: #fff;
            }
            .box{
                border: #de731c 1px solid;
            }
            
            table tr, table td{
              border: none; 
            }
        </style>
    </head>
    <body>
        <?php
        require_once './admin_header.php';
        ?>


        <div class="parts eighty_centered no_shade_noBorder box">
            <table style="border: none;">
                
                <tr>
                    
                    <td> <h2>Admin dashboard</h2></td>
                </tr>
                <tr>
                     
                    <td> <h3>Welcome to administration dashboard</h3></td>
                </tr>

            </table>
         


</div>

</body>
</html>
