<div class="parts  eighty_centered white_bg admin_heeader">     
    <div class="parts  no_paddin_shade_no_Border xxx_titles">
        Online Meal Ordering
    </div>
</div>    

<div class="parts menu eighty_centered white_bg">

    <a href="new_profile.php">profile</a>
    <a href="new_account.php">User Account</a>
    <!--<a href="new_account_category.php">account_category</a>-->
    
 
    <a href="new_dish.php">dish</a>
    <a href="new_items.php">items</a>
    <a href="new_order.php">order</a>

    <a href="new_stock.php">Stock In</a>
    <a href="new_requests.php">Stock out</a>
    <!--<a href="new_requests.php">Payments</a>-->
    
    <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
        <a href="../logout.php">Logout</a>
    </div>
</div>
