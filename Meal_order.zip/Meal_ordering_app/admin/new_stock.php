<?php
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_stock'])) {
    //save image in db
    require_once '../web_db/new_values.php';
    $new_obj = new new_values();
    $obj = new multi_values();
    $last_image = $obj->get_lastimage();
    $ext = substr(strrchr($_FILES['txt_path']['name'], "."), 1);
    $path = $last_image + 1 . '.' . $ext;
    $new_obj->new_image($path);
    $stockdeleted = 'no';
    $date = date("Y-m-d");
//    $qty_available = $_POST['txt_qty_available'];
    $qty_added = (!empty($_SESSION['update_sp_part'])) ? 0 : $_POST['txt_qty_added'];
    $account = $_SESSION['userid'];
    $comment = $_POST['txt_comment'];
    $item_name = $_POST['txt_item_name'];

    //first check if it is to update or to save
    $qty_check = $_POST['Qty_check'];
    if (!empty($_SESSION['update_sp_part'])) {
        // it is going to update instead of adding a new record
        require_once '../web_db/updates.php';
        $upd = new updates();
        $bean = new multi_values();
        $id = $_SESSION['update_sp_part'];
        
        
        $upd->update_stock($stockdeleted, $date, $account, $comment, $item_name, $id);
        unset($_SESSION['update_sp_part']);
    } else {
        $txt_measurement= $_POST['txt_measurement'];
        if (!empty($_POST['Qty_check'])) {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $item_id = $_POST['item_id'];
            $upd_obj->update_stock_qty($qty_check + $qty_added, $item_id);
        } else {
            //save_image(); // saving image in DIRRECTORY
            $new_obj->new_stock($stockdeleted, $date, $qty_added, $qty_added, $account, $comment, $item_name, $path,$txt_measurement);
        }
    }
}
//echo $_SESSION['update_sp_part'];
?>
<html>
    <head>
        <title>
            stock
        </title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/> 
        <link href="admin_style.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/></head>   <body>
        <form action="new_stock.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_account_id"   name="txt_account_id"/>
            <input type="hidden"   id="item_id"     placeholder="item id"     name="item_id" value="<?php echo get_stock_chosen_itemid(); ?>"    />
            <input type="hidden"   id="Qty_check"    placeholder="available qty"       name="Qty_check" />
            <input type="hidden"   id="existing_img"          name="existing_img"/>
            <input type="hidden"   id="update_or_not"          name="update_or_not" value="<?php echo get_stock_chosen_itemid(); ?>" />

            <div class="parts full_center_two_h heit_free margin_free no_shade_noBorder no_paddin_shade_no_Border off" id="edit_hightlight">
                <div class="parts no_paddin_shade_no_Border two_fifty_right heit_free">
                    <div class="parts no_paddin_shade_no_Border margin_free left_off_eighty">
                        <a href="#" id="upd_sp_part" >Update</a>
                    </div>
                    <div class="parts no_paddin_shade_no_Border margin_free left_off_eighty">
                        <a href="#" id="cancel_sp_part" >Cancel</a>
                    </div>
                    <div class="parts no_paddin_shade_no_Border margin_free left_off_eighty off">
                        <a href="#" id="del_sp_part" class="foreign_select_link">Delete</a>

                    </div> 
                </div>
            </div>
            <div class="parts no_paddin_shade_no_Border margin_free left_off_eighty off">
                <span  id="name_holder"></span> <?php include './Foreign_selects.php'; ?></div>
            <?php
            include 'admin_header.php';
            ?>
            <div class="parts eighty_centered no_paddin_shade_no_Border">
                <div class="new_data_hider link_cursor"> Hide </div>
            </div>
            <div class="parts eighty_centered off saved_dialog">
                stock saved successfully!</div>
            <div class="parts eighty_centered new_data_box off" id="data_div_sp_part" >
                <div class="parts heading "> New item</div>
                <div class="parts two_fifty_right heit_free  no_paddin_shade_no_Border reverse_border link_cursor" id="searched_item_box">

                </div>
                <table class="new_data_table">
                    <tr>
                        <td>Item :</td>
                        <td>
                            <input type="text" id="txt_item_name"    name="txt_item_name" required class="textbox" value="<?php echo get_stock_chosen_name(); ?>" />
                        </td>
                    </tr>
                    <tr>
                        <td>Measurement :</td>
                        <td>
                            <select class="textbox" id="txt_measurement"    name="txt_measurement" required>
                                <option></option>
                                <option>Kg</option>
                                <option>Liter</option>
                                <option>Grams</option>
                                <option>Centiliters</option>
                                <option>table cup</option>
                                <option>table spoon</option>
                                <option>table spoon</option>
                                <option>Small Bowl</option>
                                <option>Medium bowl</option>
                                <option>Small dish</option>
                                <option>medium dish</option>
                            </select>
                           
                        </td>
                    </tr>

                    <?php
                    if (!isset($_SESSION['update_sp_part'])) {
                        ?> <tr><td>qty_added :</td><td> <input type="text"     name="txt_qty_added"  class="textbox" value="<?php echo get_stock_chosen_qty(); ?>" />  </td></tr><?php
                    }
                    ?>
                    <tr><td>Comment :</td><td> <textarea     name="txt_comment"  class="textbox" ><?php echo trim(get_stock_chosen_comments()); ?></textarea>  </td></tr>
                   
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_stock" value="Save"/>  </td></tr>
                </table>
            </div>
            <div class="parts eighty_centered datalist_box" style="padding-bottom: 100px" >
                <div class="parts heading">
                     Stock Report
                </div>
                <?php
                $obj = new multi_values();
                $obj->list_stock();
                ?>
            </div>
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="date_picker/jquery-ui.js" type="text/javascript"></script>
        <script src="date_picker/jquery-ui.min.js" type="text/javascript"></script>
        <script>

            //$(".item_image").show("drop", {direction: 'left'}, 1000);
                $('.new_data_box').hide();
        </script>
    </script>
    <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</body>
</hmtl>
<?php

function get_account_combo() {
    $obj = new multi_values();
    $obj->get_account_in_combo();
}

function save_image() {
    $target_dir = "../web_images/items/";
    $target_file = $target_dir . basename($_FILES["txt_path"]["name"]);
    $uploadOk = 1;
    $imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);
    $ExtensionWithDot = '.' . $imageFileType;
    $file_with_noExtension = basename($target_file, $ExtensionWithDot);
//save the image in folder (upload)

    require_once '../web_db/multi_values.php';
    $obj2 = new multi_values();
//Last listng
    $img = $obj2->get_lastimage();
    $newname = $img . '.' . $imageFileType;
    $new_target_file = $target_dir . $newname;
    $target_file_for_db = $new_target_file;
//save the image in the db (save path)
//save the pathe in the db
// Check if image file is a actual image or fake image
    if (isset($_POST["send"])) {
        $check = getimagesize($_FILES["txt_path"]["tmp_name"]);
        if ($check !== false) {
            echo "File is an image - " . $check["mime"] . ".";
            $uploadOk = 1;
        } else {
            echo "File is not an image.";
            $uploadOk = 0;
        }
    }
// Check if file already exists
    if (file_exists($target_file)) {
//        echo "Sorry, file already exists.";
//        $uploadOk = 0;
    }
// Check file size
    if ($_FILES["txt_path"]["size"] > 3000000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }
//                    // Allow certain file formats
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "PNG" && $imageFileType != "jpeg" && $imageFileType != "gif") {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }
// Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
    } else {
        if (move_uploaded_file($_FILES["txt_path"]["tmp_name"], $new_target_file)) {
            
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }
}

// <editor-fold defaultstate="collapsed" desc="---get single fields- ---">
//here we have to check if the session (variable) for update is set and then 
//allow the display of the fields to be updated


function get_stock_chosen_itemid() {
    if (!empty($_SESSION['update_sp_part'])) {
        $id = $_SESSION['update_sp_part'];
        return $id;
    } else {
        return '';
    }
}

function get_stock_chosen_name() {
    if (!empty($_SESSION['update_sp_part'])) {
        $bean = new multi_values();
        $id = $_SESSION['update_sp_part'];
        return $bean->get_chosen_stock_name($id);
    } else {
        return '';
    }
}

function get_stock_chosen_qty() {
    if (!empty($_SESSION['update_sp_part'])) {
        $bean = new multi_values();
        $id = $_SESSION['update_sp_part'];
        return $bean->get_chosen_stock_qty($id);
    } else {
        return '';
    }
}

function get_stock_chosen_comments() {
    if (!empty($_SESSION['update_sp_part'])) {
        $bean = new multi_values();
        $id = $_SESSION['update_sp_part'];
        return $bean->get_chosen_stock_comments($id);
    } else {
        return '';
    }
}

function get_stock_chosen_image() {
    if (!empty($_SESSION['update_sp_part'])) {
        $id = $_SESSION['update_sp_part'];
//        return $bean->get_chosen_stock_name($id);
    } else {
        return '';
    }
}

// </editor-fold>

