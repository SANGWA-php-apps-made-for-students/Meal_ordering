<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        
        <link href="jquery-ui.css" rel="stylesheet" type="text/css"/>
        <link href="jquery-ui.min.css" rel="stylesheet" type="text/css"/>
        <link href="jquery-ui.structure.css" rel="stylesheet" type="text/css"/>
        <link href="jquery-ui.structure.min.css" rel="stylesheet" type="text/css"/>
        <link href="jquery-ui.theme.css" rel="stylesheet" type="text/css"/>
        <link href="jquery-ui.theme.min.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <?php
        ?>
        <div class="parts seventy_centered">
            <div class="parts full_center_two_h no_shade_noBorder">
                <div class="parts margin_free x_titles no_paddin_shade_no_Border">
                    <div class="parts no_paddin_shade_no_Border" >
                        Scripts
                        <input type="text" id="date">
                    </div>
                    <div class="parts no_paddin_shade_no_Border two_fifty_right heit_free">
                        Get on
                    </div>
                </div>
            </div>
        </div>
    </body>
    <script src="jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="jquery-ui.js" type="text/javascript"></script>
    <script src="jquery-ui.min.js" type="text/javascript"></script>
    <script src="my_scripts.js" type="text/javascript"></script>
</html>
