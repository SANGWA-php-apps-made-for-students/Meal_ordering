
<div class="parts abs_full off foreign_select">

</div>

<div class="parts dialog eighty_centered  no_paddin_shade_no_Border off" style="left: 2%; top:0px">
    <div class="parts title margin_free full_center_two_h heit_free no_shade_noBorder " style="background-color: #f75d77;">
        <span class="dialog_title" style="color: #fff;" ></span>
    </div>
    <div class="parts tables  no_shade_noBorder reverse_border" id="profile">
        <?php list_selectable_profile() ?>
    </div>
    <div class="parts tables off no_shade_noBorder reverse_border" id="category">
        <?php list_selectable_acc_category(); ?>
    </div>
    <div class="parts tables  off no_shade_noBorder reverse_border" id="spares">
        <?php list_selectable_stock(); ?>
    </div>
    <div class="parts tables  off no_shade_noBorder reverse_border" id="delete_stock">
        <div class="parts two_fifty_left  yes_no_btns" id="del_yes" >Yes</div>
        <div class="parts two_fifty_right yes_no_btns" id="del_no">No</div>
    </div>

</div>

<?php
//selectables
require_once '../web_db/connection.php';

function list_selectable_acc_category() {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from account_category ";
    ?>
    <table class="dataList_table">
        <thead><tr>
                <td> ID </td>
                <td> name </td>
                <td>Option</td>
        </thead>
        <?php foreach ($db->query($sql) as $row) { ?><tr>
                <td class="category_col">
                    <?php echo $row['account_category_id']; ?>
                </td>
                <td class="cat_names_col">
                    <?php echo $row['name']; ?>
                </td>

                <td>
                    <a href="#" class="select_link_account_category" style="color: #000080;" value="
                       <?php echo $row['account_category_id']; ?>">Select</a>
                </td></tr>
        <?php } ?></table>
    <?php
}

function list_selectable_profile() {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from profile   ";
    ?>
    <table class="dataList_table">
        <thead><tr>
                <td> profile </td>

                <td> name </td>

                <td>Delete</td><td>Update</td></tr></thead>
        <?php foreach ($db->query($sql) as $row) { ?><tr>

                <td class="profile_id_col">
                    <?php echo $row['profile_id']; ?>
                </td>
                <td>
                    <?php echo $row['dob']; ?>
                </td>
                <td class="profile_names_col">
                    <?php echo $row['name']; ?>
                </td>
                <td>
                    <a href="#" class="select_link_profile" style="color: #000080;" value="
                       <?php echo $row['profile_id']; ?>">Select</a>
                </td>
            </tr>
        <?php } ?></table>
    <?php
}

function list_selectable_stock() {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from stock   ";
    ?>
    <table class="dataList_table">
        <thead><tr>
                <td> stock </td>

                <td> qty_available </td>


                <td> item_name </td>
                <td> date </td>

                <td>Option</td></tr></thead>

        <?php foreach ($db->query($sql) as $row) { ?><tr>

                <td class="item_id_col">
                    <?php echo $row['stock_id']; ?>
                </td>


                <td>
                    <?php echo $row['qty_available']; ?>
                </td>

                <td class="item_name_col">
                    <?php echo $row['item_name']; ?>
                </td>
                <td>
                    <?php echo $row['date']; ?>
                </td>
                <td>
                    <a href="#" class="select_link_stockstock" style="color: #000080;" value="
                       <?php echo $row['stock_id']; ?>">Select</a>
                </td> </tr>
        <?php } ?></table>
    <?php
}
