<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Home</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>  
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>  
        <link href="web_style/commons.css" rel="stylesheet" type="text/css"/>
        <style>
            .brd{
                border: #2eb3a8 1px solid;
            }
        </style>
    </head>
    <body class="homepage">
        <div class="home_user_ordering_form"> </div>
        <div class="home_user_ordering_bg">
            <table>
                <tr>
                    <td>Telephone</td>
                </tr>
                <tr>
                    <td>NUmber dishes</td>
                </tr>
                <tr>
                    <td><input type=""></td>

                    <td>   </td>
                </tr>
            </table>

        </div>
        <?php
        include 'header_menu.php';
        ?>

        <div id="fb-root"></div>
        <script>(function (d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id))
                    return;
                js = d.createElement(s);
                js.id = id;
                js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.10";
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));</script>        

        <div class="parts no_shade_noBorder eighty_centered white_bg">
            <?php
            require_once 'web_db/connection.php';

            function get_first_dish() {
                $con = new dbconnection();
                $sql = "select dish.dish_id from dish
                    order by dish.dish_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['dish_id'];
                return $first_rec;
            }

            list_dish(get_first_dish());

            function list_dish($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from dish";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>


                <style>
                    .home_dishes{
                        display: grid;
                        grid-gap: 20px;
                        grid-template-columns: repeat(15,150px);
                        position: relative;
                    }
                    .home_dishes div{
                        position: relative;
                    }

                    .home_dishes::after{
                        position: absolute;
                        left: 0px;
                        top: 0px;
                        width: 100%;
                        height: 100%;
                        background-color: #000;
                        /*opacity: 0.8;*/

                    }
                    .home_dishes .img_box{
                        /*border: #ff7200 2px solid;*/
                    }
                    .home_dishes div:hover{
                        box-shadow: 0px 0px 5px #000;

                    }
                    .home_dishes div .dish_name{
                        box-sizing: border-box;
                        position: absolute;
                        width: 100%;
                        bottom: 0px;
                        background-color: #815b10;
                        color: #fff;
                        padding: 7px;
                    }
                </style>

                <div class="parts no_shade_noBorder eighty_centered home_dishes">
                    <?php
                    $pages = 1;
                    while ($row = $stmt->fetch()) {
                        ?> 
                        <?php echo '<div onclick="how_bg(this)" class="img_box" data-pricetag="' . $row['price'] . '"    data-bind="' . $row['dish_id'] . '"><div class="dish_name">' . $row['name'] . ' (Rfr ' . $row['price'] . ') </div>  <img height="150" width="150" src="admin/my_dishes/' . $row['picture'] . '"/></div>'; ?>

                        <?php
                        $pages += 1;
                    }
                    ?>
                </div>

                <?php
            }
            ?>
        </div>
        <div class="parts eighty_centered x_height_4x  no_paddin_shade_no_Border home_shortciut">

            <div class="off ">Start ordering</div>
            <div class="off">Register</div>
            <div class="off">View best dished</div>
        </div>
        <!--        <div class="parts eighty_centered footer">
                    Copyrights <?php echo date("Y"); ?>
                    <div class="fb-share-button" data-href="https://www.codeguru-pro.net" data-layout="button_count" data-size="small" data-mobile-iframe="true"><a class="fb-xfbml-parse-ignore" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fwww.codeguru-pro.net%2Ftests%2Findex.php&amp;src=sdkpreparse">Share</a></div> 
                </div> -->
        <div class="w_pctg_90 clr_bg lg_h_500 lg_txt_17  off">

        </div>

        <script src="web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="web_scripts/web_scripts.js" type="text/javascript"></script>

        <script>
            $('.home_shortciut div').delay(500).show();
            $('.home_shortciut div').css('display', 'grid');





            //Make an ordering form
            var dishid = 0;
            var price = '';

            $(document).ready(function () {

                create_user_form();




                //You content
            });

            function d() {
                return $(document.createElement('div'));
            }

            function how_bg(item) {//this should be valled show bg
                $('.hmpage_order_form, .bg_overlay').fadeIn(400);
                dishid = $(item).data('bind');
                price = $(item).data('pricetag');


            }

            function send_order() {
                var name = $('.txt_name').val();
                var tel = $('.txt_tel').val();
                if (name !== '' && tel !== '') {
                    $.post('admin/handler.php', {send_order: 'send_order', price: price, name: name, tel: tel, dishid: dishid}, function (data) {
                        console.log('Data: ' + data);
                        alert(data);
                    }).complete(function () {
                        $('.bg_overlay, .hmpage_order_form').fadeOut(100);
                    });
                }
            }
            function cbo_payment_selected() {
                $('#payment_li').html(`Payment: ${$(this).val()},     Amount: ${price}        `);
                $('#payment_li2').html(``);
                $('.payment_title').show();
            }
            function create_user_form() {

                var bg = $(document.createElement('div')).addClass('fixd w_pctg_100 bg_overlay top_left abs1 off')
                        .appendTo('body').on('click', function () {
                    $(this).fadeOut(300);
                    $('.hmpage_order_form').fadeOut();
                });
                var form = $(document.createElement('div')).addClass('off hmpage_order_form  w_pctg_60 h_pctg_100 clr_bg lg_h_500 col_sm_12')
                        .append($(document.createElement('div')).addClass('title w_pctg_100 pad lg_txt_17 ').html('Ordering form'))
                        .append($(document.createElement('div')).addClass('content w_pctg_100 pad ')
                                .append(d().addClass('row')
                                        .append(
                                                d().addClass('col_lg_2 pad').html('Name')
                                                )
                                        .append(
                                                d().addClass('col_lg_10 pad').append(
                                                $(document.createElement('input')).addClass('textbox txt_name pad brd').attr('type', 'text').attr('placeholder', 'Name').css('border', '#2eb3a8 1px solid')
                                                ))
                                        .append(
                                                d().addClass('col_lg_2 pad').html('Telephone')
                                                )
                                        .append(
                                                d().addClass('col_lg_10 pad').append(
                                                $(document.createElement('input')).addClass('textbox txt_tel pad brd').attr('type', 'text').attr('placeholder', 'Telephoone').css('border', '#2eb3a8 1px solid')
                                                ))

                                        .append(
                                                d().addClass('col_lg_2 pad').html('Payment')
                                                )
                                        .append(
                                                d().addClass('col_lg_10 pad').append(
                                                $(document.createElement('select')).addClass('textbox txt_cbo_payment pad brd').css('border', '#2eb3a8 1px solid')
                                                .append('<option></option>  <option value=\"visa\">Visa card</option> <option value=\"momo\">Momo </option> <option value=\"paypal\">Paypal </option>').on('change select:option', cbo_payment_selected))
                                                )
                                        .append(
                                                d().addClass('col_lg_12').append($(document.createElement('h2')).html('Payment selected:').addClass('off payment_title'))
                                                )
                                        .append(
                                                $(document.createElement('ul'))
                                                .append('li').addClass('col_lg_12').attr('id', 'payment_li').html('')
                                                
                                                )
                                        .append(
                                                d().addClass('col_lg_12 row pad').append(
                                                d().addClass('col_lg_10')).append(
                                                $(document.createElement('input')).addClass('col_lg_2 pad').attr('type', 'button').val('Send').on('click', send_order)
                                                ))

                                        )
                                );
                form.appendTo('body');

                return form;
            }



        </script>


    </body>
</html>
