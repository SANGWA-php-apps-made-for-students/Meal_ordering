<?php
require_once '../web_db/connection.php';

class multi_values {

    function list_account($min) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from account join profile on profile.profile_id=account.profile";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));
        ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> account </td>
                    <td class="off"> Category </td><td> Date created </td><td>Profile  </td>
                    <td> Username </td><td class="off">Password  </td> 
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['account_id']; ?>
                    </td>
                    <td class="account_category_id_cols account off " title="account" >
                        <?php echo $this->_e($row['account_category']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['date_created']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['name']. ' '.$row['last_name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['username']); ?>
                    </td>
                    <td class="off">
                        <?php echo $this->_e($row['password']); ?>
                    </td>



                    <td>
                        <a href="#" class="account_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['account_id']; ?>"  data-table="account">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="account_update_link" style="color: #000080;" data-id_update="<?php echo $row['account_id']; ?>" data-table="account" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_account_account_category($id) {

            $db = new dbconnection();
            $sql = "select   account.account_category from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['account_category'];
            echo $field;
        }

        function get_chosen_account_date_created($id) {

            $db = new dbconnection();
            $sql = "select   account.date_created from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['date_created'];
            echo $field;
        }

        function get_chosen_account_profile($id) {

            $db = new dbconnection();
            $sql = "select   account.profile from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['profile'];
            echo $field;
        }

        function get_chosen_account_username($id) {

            $db = new dbconnection();
            $sql = "select   account.username from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['username'];
            echo $field;
        }

        function get_chosen_account_password($id) {

            $db = new dbconnection();
            $sql = "select   account.password from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['password'];
            echo $field;
        }

        function get_chosen_account_is_online($id) {

            $db = new dbconnection();
            $sql = "select   account.is_online from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['is_online'];
            echo $field;
        }

        function All_account() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  account_id   from account";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_account() {
            $con = new dbconnection();
            $sql = "select account.account_id from account
                    order by account.account_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_id'];
            return $first_rec;
        }

        function get_last_account() {
            $con = new dbconnection();
            $sql = "select account.account_id from account
                    order by account.account_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_id'];
            return $first_rec;
        }

        function list_account_category($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from account_category";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> account_category </td>
                    <td>  </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['account_category_id']; ?>
                    </td>
                    <td class="name_id_cols account_category " title="account_category" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>


                    <td>
                        <a href="#" class="account_category_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['account_category_id']; ?>"  data-table="account_category">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="account_category_update_link" style="color: #000080;" data-id_update="<?php echo $row['account_category_id']; ?>" data-table="account_category" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_account_category_name($id) {

            $db = new dbconnection();
            $sql = "select   account_category.name from account_category where account_category_id=:account_category_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_category_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function All_account_category() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  account_category_id   from account_category";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_account_category() {
            $con = new dbconnection();
            $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_category_id'];
            return $first_rec;
        }

        function get_last_account_category() {
            $con = new dbconnection();
            $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_category_id'];
            return $first_rec;
        }

        function list_profile($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from profile";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> profile </td>
                    <td> Name </td><td> Last name </td> 
                    <td> Telephone </td><td> Email </td><td> Residence </td><td>  </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['profile_id']; ?>
                    </td>

                    <td>
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['last_name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['telephone_number']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['email']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['residence']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['image']); ?>
                    </td>


                    <td>
                        <a href="#" class="profile_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['profile_id']; ?>"  data-table="profile">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="profile_update_link" style="color: #000080;" data-id_update="<?php echo $row['profile_id']; ?>" data-table="profile" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_profile_dob($id) {

            $db = new dbconnection();
            $sql = "select   profile.dob from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['dob'];
            echo $field;
        }

        function get_chosen_profile_name($id) {

            $db = new dbconnection();
            $sql = "select   profile.name from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function get_chosen_profile_last_name($id) {

            $db = new dbconnection();
            $sql = "select   profile.last_name from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['last_name'];
            echo $field;
        }

        function get_chosen_profile_gender($id) {

            $db = new dbconnection();
            $sql = "select   profile.gender from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['gender'];
            echo $field;
        }

        function get_chosen_profile_telephone_number($id) {

            $db = new dbconnection();
            $sql = "select   profile.telephone_number from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['telephone_number'];
            echo $field;
        }

        function get_chosen_profile_email($id) {

            $db = new dbconnection();
            $sql = "select   profile.email from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['email'];
            echo $field;
        }

        function get_chosen_profile_residence($id) {

            $db = new dbconnection();
            $sql = "select   profile.residence from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['residence'];
            echo $field;
        }

        function get_chosen_profile_image($id) {

            $db = new dbconnection();
            $sql = "select   profile.image from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['image'];
            echo $field;
        }

        function All_profile() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  profile_id   from profile";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_profile() {
            $con = new dbconnection();
            $sql = "select profile.profile_id from profile
                    order by profile.profile_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['profile_id'];
            return $first_rec;
        }

        function get_last_profile() {
            $con = new dbconnection();
            $sql = "select profile.profile_id from profile
                    order by profile.profile_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['profile_id'];
            return $first_rec;
        }

        function list_image($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from image";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> image </td>
                    <td>  </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['image_id']; ?>
                    </td>
                    <td class="path_id_cols image " title="image" >
                        <?php echo $this->_e($row['path']); ?>
                    </td>


                    <td>
                        <a href="#" class="image_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['image_id']; ?>"  data-table="image">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="image_update_link" style="color: #000080;" data-id_update="<?php echo $row['image_id']; ?>" data-table="image" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_image_path($id) {

            $db = new dbconnection();
            $sql = "select   image.path from image where image_id=:image_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':image_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['path'];
            echo $field;
        }

        function All_image() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  image_id   from image";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_image() {
            $con = new dbconnection();
            $sql = "select image.image_id from image
                    order by image.image_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['image_id'];
            return $first_rec;
        }

        function get_last_image() {
            $con = new dbconnection();
            $sql = "select image.image_id from image
                    order by image.image_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['image_id'];
            return $first_rec;
        }

        function list_dish($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from dish";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> Dish </td> 
                    <td> Name </td>
                    <td> Price </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <div class="" style="width: 90px; height: 90px; border: 1px solid #000; background-image: url('../admin/my_dishes/<?php echo $this->_e($row['picture']) ?>')"></div>

                        <?php echo $this->_e($row['picture']); ?>
                    </td>
                    <td class="price_id_cols dish " title="dish" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td class="price_id_cols dish " title="dish" >
                        <?php echo $this->_e($row['price']); ?>
                    </td>



                    <td>
                        <a href="#" class="dish_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['dish_id']; ?>"  data-table="dish">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="dish_update_link" style="color: #000080;" data-id_update="<?php echo $row['dish_id']; ?>" data-table="dish" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_dish_price($id) {

            $db = new dbconnection();
            $sql = "select   dish.price from dish where dish_id=:dish_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':dish_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['price'];
            echo $field;
        }

        function get_chosen_dish_name($id) {

            $db = new dbconnection();
            $sql = "select   dish.name from dish where dish_id=:dish_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':dish_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['price'];
            echo $field;
        }

        function get_chosen_dish_picture($id) {

            $db = new dbconnection();
            $sql = "select   dish.picture from dish where dish_id=:dish_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':dish_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['picture'];
            echo $field;
        }

        function All_dish() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  dish_id   from dish";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_dish() {
            $con = new dbconnection();
            $sql = "select dish.dish_id from dish
                    order by dish.dish_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['dish_id'];
            return $first_rec;
        }

        function get_last_dish() {
            $con = new dbconnection();
            $sql = "select dish.dish_id from dish
                    order by dish.dish_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['dish_id'];
            return $first_rec;
        }

        function list_items($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql =""
                    . "  select items.items_id, items.name as item_name, dish.name, dish.price  from items join dish on items.dish=dish.dish_id;";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> items </td>
                    <td> Item </td>
                    <td> Dish </td>
                    <td> Price </td>
               
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
            <?php echo $row['items_id']; ?>
                    </td>
                    <td class="name_id_cols items " title="items" >
            <?php echo $this->_e($row['item_name']); ?>
                    </td>
                    <td>
            <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
            <?php echo $this->_e($row['price']); ?>
                    </td>


                    <td>
                        <a href="#" class="items_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['items_id']; ?>"  data-table="items">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="items_update_link" style="color: #000080;" data-id_update="<?php echo $row['items_id']; ?>" data-table="items" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_items_name($id) {

            $db = new dbconnection();
            $sql = "select   items.name from items where items_id=:items_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':items_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function get_chosen_items_dish($id) {

            $db = new dbconnection();
            $sql = "select   items.dish from items where items_id=:items_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':items_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['dish'];
            echo $field;
        }

        function All_items() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  items_id   from items";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_items() {
            $con = new dbconnection();
            $sql = "select items.items_id from items
                    order by items.items_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['items_id'];
            return $first_rec;
        }

        function get_last_items() {
            $con = new dbconnection();
            $sql = "select items.items_id from items
                    order by items.items_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['items_id'];
            return $first_rec;
        }

        function list_order($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select order_tbl.order_id, order_tbl.entry_date, order_tbl.tel,"
                    . " profile.name, profile.last_name,"
                    . " dish.name as dish_name from order_tbl "
                    . " join account on account.account_id= order_tbl.User"
                    . " join profile on profile.profile_id=account.profile"
                    . " join dish on dish.dish_id=order_tbl.dish "
                    . " ";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> order </td>
                    <td> Dish </td>
                    <td> Entry Date </td><td> User </td><td> Tel </td><td>Option</td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td> <?php echo $row['order_id']; ?></td>
                    <td> <?php echo $row['dish_name']; ?></td>
                    <td class="entry_date_id_cols order " title="order" >
            <?php echo $this->_e($row['entry_date']); ?>
                    </td>
                    <td>
            <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
            <?php echo $this->_e($row['tel']); ?>
                    </td>
                    <td>
                        <a href="#" class="order_confirm_link " style="color: #000080;"  data-bind="<?php echo $row['order_id']; ?>"  data-table="order">Confirm</a>
                    </td>
                    <td>
                        <a href="#" class="order_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['order_id']; ?>"  data-table="order">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="order_update_link" style="color: #000080;" data-id_update="<?php echo $row['order_id']; ?>" data-table="order" >Update</a>
                    </td>
                </tr>
                <?php
                $pages += 1;
            }
            ?></table>
        <?php
    }

    function list_order_by_status($status) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select order_tbl.order_id, order_tbl.entry_date, order_tbl.tel,"
                . " profile.name, profile.last_name,"
                . " dish.name as dish_name, dish.price from order_tbl "
                . " join account on account.account_id= order_tbl.User"
                . " join profile on profile.profile_id=account.profile"
                . " join dish on dish.dish_id=order_tbl.dish"
                . " where order_tbl.status=:status "
                . " ";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":status" => $status));
        ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> order </td>
                    <td> Dish </td>
                    <td> Price </td>
                    <td> Entry Date </td><td> User </td><td> Tel </td><td>Option</td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 
                    <td> <?php echo $row['order_id']; ?></td>
                    <td> <?php echo $row['dish_name']; ?></td>
                    <td> <?php echo $row['price']; ?></td>
                    <td class="entry_date_id_cols order " title="order" >
                        <?php echo $this->_e($row['entry_date']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
            <?php echo $this->_e($row['tel']); ?>
                    </td>
                    <td>
                        <a href="#" class="order_confirm_link " style="color: #000080;"  data-bind="<?php echo $row['order_id']; ?>"  data-table="order">Confirm</a>
                    </td>
                    <td>
                        <a href="#" class="order_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['order_id']; ?>"  data-table="order">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="order_update_link" style="color: #000080;" data-id_update="<?php echo $row['order_id']; ?>" data-table="order" >Update</a>
                    </td>
                </tr>
                <?php
                $pages += 1;
            }
            ?></table>
        <?php
    }

    function list_order_by_status_noconfirmebtn($status) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select order_tbl.order_id, order_tbl.entry_date, order_tbl.tel,"
                . " profile.name, profile.last_name,"
                . " dish.name as dish_name from order_tbl "
                . " join account on account.account_id= order_tbl.User"
                . " join profile on profile.profile_id=account.profile"
                . " join dish on dish.dish_id=order_tbl.dish"
                . " where order_tbl.status=:status "
                . " ";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":status" => $status));
        ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> order </td>
                    <td> Dish </td>
                    <td> Entry Date </td><td> User </td><td> Tel </td> 
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td> <?php echo $row['order_id']; ?></td>
                    <td> <?php echo $row['dish_name']; ?></td>
                    <td class="entry_date_id_cols order " title="order" >
                        <?php echo $this->_e($row['entry_date']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
            <?php echo $this->_e($row['tel']); ?>
                    </td>

                    <td>
                        <a href="#" class="order_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['order_id']; ?>"  data-table="order">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="order_update_link" style="color: #000080;" data-id_update="<?php echo $row['order_id']; ?>" data-table="order" >Update</a>
                    </td>
                </tr>
                <?php
            $pages += 1;
        }
        ?></table>
        <?php
    }

//chosen individual field
    function get_chosen_order_entry_date($id) {

        $db = new dbconnection();
        $sql = "select   order.entry_date from order where order_id=:order_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':order_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['entry_date'];
        echo $field;
    }

    function get_chosen_order_User($id) {

        $db = new dbconnection();
        $sql = "select   order.User from order where order_id=:order_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':order_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['User'];
        echo $field;
    }

    function get_chosen_order_tel($id) {

        $db = new dbconnection();
        $sql = "select   order.tel from order where order_id=:order_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':order_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['tel'];
        echo $field;
    }

    function All_order() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  order_id   from order";
        foreach ($db->query($sql) as $row) {
            $c += 1;
        }
        return $c;
    }

    function get_first_order() {
        $con = new dbconnection();
        $sql = "select order.order_id from order
                    order by order.order_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['order_id'];
        return $first_rec;
    }

    function get_last_order() {
        $con = new dbconnection();
        $sql = "select order.order_id from order
                    order by order.order_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['order_id'];
        return $first_rec;
    }

    function get_account_category_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account_category.account_category_id,   account_category.name from account_category";
        ?>
        <select class="textbox cbo_account_category"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_category_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_profile_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.profile_id,   profile.name from profile";
        ?>
        <select class="textbox cbo_profile"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['profile_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_image_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select image.image_id,   image.name from image";
        ?>
        <select class="textbox cbo_image"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['image_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_dish_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select dish.dish_id   ,price, name from dish";
        ?>
        <select class="textbox cbo_dish " name="cbo_dish"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['dish_id'] . ">" . $row['dish_id'] . ' - ' . $row['name'] . '  =>( Rfr ' . $row['price'] . ") </option>";
                }
                ?>
        </select>
        <?php
    }

    function _e($string) {
        echo htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
    }

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    // <editor-fold defaultstate="collapsed" desc="-------------------Stock fnxs --------------">
   
    
  
    
    function list_contact_us() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from contact_us where contact_us.deleted='no'  ";
        ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> contact_us </td>
                    <td> account </td>
                    <td> date_contact </td>
                    <td> message </td>

                    <td>Delete</td><td>Update</td></tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr>

                    <td>
                        <?php echo $row['contact_us_id']; ?>
                    </td>
                    <td>
                        <?php echo $row['account']; ?>
                    </td>
                    <td>
                        <?php echo $row['date_contact']; ?>
                    </td>
                    <td>
                        <?php echo $row['message']; ?>
                    </td>


                    <td>
                        <a href="#" class="delete_link_contact_uscontact_us" style="color: #000080;" value="
                           <?php echo $row['contact_us_id']; ?>">Delete</a>
                    </td><td>
                        <a href="#" class="update_link_contact_uscontact_us" style="color: #000080;" value="
                           <?php echo $row['contact_us_id']; ?>">Update</a>
                    </td></tr>
            <?php } ?></table>
        <?php
    }

    function list_requests() {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from requests join profile on profile.profile_id=requests.profile  ";
        ?>  
        <table class="dataList_table">
            <thead><tr>
                    <td> requests </td>
                    <td> date </td>
                    <td> qty </td>
                    <td> account </td>
                    <td> profile </td>

                    <td>Delete</td><td>Update</td></tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr>

                    <td class="req_cols">
                        <?php echo $row['requests_id']; ?>
                    </td>
                    <td>
                        <?php echo $row['date']; ?>
                    </td>
                    <td>
                        <?php echo $row['qty']; ?>
                    </td>
                    <td>
                        <?php echo $row['account']; ?>
                    </td>
                    <td>
                        <?php echo $row['name']. ' '.$row['last_name']; ?>
                    </td>
                    <td>
                        <a href="#" class="delete_link_request" style="color: #000080;" value="
                           <?php echo $row['requests_id']; ?>">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="update_link_request" style="color: #000080;" value="
                           <?php echo $row['requests_id']; ?>">Update</a>
                    </td></tr>
            <?php } ?></table>
        <?php
    }

    function list_stock() {

         $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from stock    ";
        ?>  
        <table class="dataList_table">
            <thead><tr>
                    <td> ID </td>
                    <td> Item </td>
                    <td> qty </td>
                    
 
                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr>

                    <td class="req_cols">
                        <?php echo  $row['stock_id']; ?>
                    </td>
                    <td>
                        <?php echo $row['item_name']; ?>
                    </td>
                    <td>
                        <?php echo $row['qty_available'].' '.$row['measurement']; ?>
                    </td>
                     
            </tr>
            <?php } ?></table>
        <?php
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
       
    }

    function get_lastaccount() {

        $db = new dbconnection();
        $sql = "select   account.account_id from account order by account.account_id desc limit 1";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['account_id'];
        return $userid;
    }

    
    function get_account_category_id_by_account_category_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    account_category.account_category_id from account_category where account_category.name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['account_category_id'];
        echo $userid;
    }

    function get_profile_id_by_profile_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    profile.profile_id from profile where profile.name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['profile_id'];
        echo $userid;
    }

     
    function get_image_id_by_image_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    image.image_id from image where image.name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['image_id'];
        echo $userid;
    }

    function get_account_id_by_account_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    account.account_id from account where account.name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['account_id'];
        echo $userid;
    }
 
    function get_account_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.account_id,   account.name from account";
        ?>
        <select class="textbox cbo_account"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
        </select>
        <?php
    }

    //addon
    function get_lastprofile() {

        $db = new dbconnection();
        $sql = "select   profile.profile_id from profile order by profile.profile_id desc limit 1";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['profile_id'];
        return $userid;
    }

    function get_lastimage() {
        $db = new dbconnection();
        $sql = "select   image.image_id from image order by image.image_id desc limit 1";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['image_id'];
        return $userid;
    }

   
    function get_item_search($item) {
        ?>
        <script> $('.prod_names').unbind('click').click(function () {
                var item_id = $(this).attr('value');
                var item_name = $(this).text();
                var quantity_av = item_id;
                $('#file_image').hide('drop', {direction: 'up'}, 500);
                $('#item_id').val(item_id);
                $('#txt_item_name').val(item_name);
                $.post('../Admin/handler.php', {quantity_av: quantity_av}, function (data) {
                    $('#Qty_check').val(data);
                }).complete(function () {
                    var get_stock_image_by_item_id = 'c';
                    $.post('../Admin/handler.php', {get_stock_image_by_item_id: get_stock_image_by_item_id, item_id: item_id}, function (data) {

                    }).complete(function () {

                    });
                });
            });</script><?php
        $db = new dbconnection();
        $stmt = $db->openconnection()->prepare("SELECT distinct stock_id, item_name from stock where item_name LIKE ?");
        $stmt->bindValue(1, "%$item%", PDO::PARAM_STR);
        $stmt->execute();
        while ($row = $stmt->fetch()) {
            echo '<br/><a href="#" class="prod_names" style="margin:5px;"   value="' . $row['stock_id'] . '" >' . $row['item_name'] . '</a>';
        }
    }

    function get_qty_available_by_stock($stock_id) {
        $con = new dbconnection();
        $sql = "select    qty_available  from stock   where  stock.stock_id = '$stock_id'   order by stock_id desc  limit 1 ";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['qty_available'];
        return $userid;
    }

    function get_stock_image_by_item_id($stock_id) {
        $con = new dbconnection();
        $sql = "select    image  from stock where  stock.stock_id = '$stock_id'   ";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['image'];
        return $userid;
    }

    // <editor-fold defaultstate="collapsed" desc="--single fields for updates ---">
    //this is the stock

    function get_chosen_stock_itemid($id) {
        $con = new dbconnection();
        $sql = "select stock.stock_id from stock where stock_id = :stockid   ";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array("stockid" => $id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['stock_id'];
        return $userid;
    }

    function get_chosen_stock_name($id) {
        $con = new dbconnection();
        $sql = "select stock.item_name  from stock where stock_id = :stockid   ";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array("stockid" => $id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['item_name'];
        return $userid;
    }

    function get_chosen_stock_qty($id) {
        $con = new dbconnection();
        $sql = "select stock.qty_added  from stock where stock_id=:stockid  order by stock_id desc limit 1  ";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array("stockid" => $id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['qty_added'];
        return $userid;
    }

    function get_chosen_stock_comments($id) {
        $con = new dbconnection();
        $sql = "select stock.comment  from stock where stock_id = :stockid   ";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array("stockid" => $id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['comment'];
        return $userid;
    }

    function get_stock_image($id) {
        $con = new dbconnection();
        $sql = "select stock.image  from stock where stock_id = :stockid   ";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array("stockid" => $id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['image'];
        return $userid;
    }

    function get_chosen_stock_av_qty($id) {
        $con = new dbconnection();
        $sql = "select stock.qty_available  from stock where stock_id = :stockid   ";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute(array("stockid" => $id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['qty_available'];
        return $userid;
    }

// </editor-fold>

}
