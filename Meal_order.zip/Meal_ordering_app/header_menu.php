<div class="parts  eighty_centered white_bg">     
    <div class="parts  no_paddin_shade_no_Border xxx_titles">
        Online Meal Ordering
    </div>
</div>    

<div class="parts menu eighty_centered white_bg">
    <a href="index.php">Home</a>
    
    
    
<!--    <a href="new_account_category.php">O</a>
    <a href="new_profile.php">profile</a>
    <a href="new_image.php">image</a>
    <a href="new_dish.php">dish</a>
    <a href="new_items.php">items</a>
    <a href="new_order.php">order</a>-->

    <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
        <a href="login.php">Login</a>
    </div>
</div>
